import scalaj.http._
import spray.json._
import java.io._
import scala.io._
import org.apache.http.HttpEntity
import org.apache.http.HttpResponse
import org.apache.http.client.ClientProtocolException
import org.apache.http.client._
import org.apache.http.client.methods.HttpGet
import org.apache.commons.codec.binary.Base64
import scala.collection.mutable.StringBuilder
import java.net.URL

 object SensorData extends App {
  // Node IDs 0e34909f-f07f-417c-a667-bf7b12757eef, 373c0f3d-71b8-4925-b13d-0d80ffb9f701, ccecc389-73e7-493b-b6bb-1570ad93fd75
  //https://hackathon.720.fi/nodes/ccecc389-73e7-493b-b6bb-1570ad93fd75/measurements?from=2016-11-15T18:45:00&until=2016-11-25T18:45:00&aggregate=6h
    
      val nodeIDs = Vector("0e34909f-f07f-417c-a667-bf7b12757eef", "373c0f3d-71b8-4925-b13d-0d80ffb9f701", "ccecc389-73e7-493b-b6bb-1570ad93fd75")
      val contentType = Map("Accept" -> "application/json")
    for(nodeID <- 0 until 3) { 
      val connection = new URL("https://hackathon.720.fi/nodes/" + nodeIDs(nodeID) + "/measurements?from=2016-11-18T18:45:00&until=2016-11-25T18:45:00&aggregate=1h").openConnection
      connection.setRequestProperty(HttpBasicAuth.AUTHORIZATION, HttpBasicAuth.getHeader("junction_hackathon@720.fi", "i<3python"))
   
      val response = Source.fromInputStream(connection.getInputStream).getLines.mkString("\n")
      val sortResponse = response //.split("record_time").mkString("\n")
    
      println(sortResponse)
  }
}
/*object SensorData extends App {
  
    override def main(args: Array[String]) {
      
    for(page <- 1 to 100) {
      val contentType = Map("Accept" -> "application/json")
      val connection = new URL("https://tieto.iottc.tieto.com/measurement/measurements?dateFrom=2016-10-14&dateTo2016-10-24/&pageSize=5&currentPage=" + page + "&dateFrom=2016-10-14").openConnection
      connection.setRequestProperty(HttpBasicAuth.AUTHORIZATION, HttpBasicAuth.getHeader("junction_hacker", "e*@ND_2foa"))
      
      contentType.foreach({
        case (name, value) => connection.setRequestProperty(name, value)
          })
      val response = Source.fromInputStream(connection.getInputStream).getLines.mkString("\n")
      val sortResponse = response.split("time").mkString("\n")
      println(sortResponse)
      }
    }
}*/

object HttpBasicAuth {
  
   val BASIC = "Basic"
   val AUTHORIZATION = "Authorization"

   def encodeCredentials(username: String, password: String): String = {
      new String(Base64.encodeBase64String((username + ":" + password).getBytes))
   }

   def getHeader(username: String, password: String): String = 
      BASIC + " " + encodeCredentials(username, password)
}